<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "sehs3245_101_group_2_sleipnir";