    <meta charset="utf-8">
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="SLEIPNIR, where the supreme fusion of luxury and passion awaits." />
    <meta name="keywords" content="SLEIPNIR, passion, fusion, sport cars, luxury" />
    <link href="images/favicon-32x32.png" rel="icon" type="image/png" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://sleipnir.shop/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://sleipnir.shop/css/bootstrap-theme.min.css">

    <!-- Jquery CSS -->
    <link rel="stylesheet" href="https://sleipnir.shop/css/jquery-ui.min.css">

    <!-- Slider CSS -->
    <link rel="stylesheet" href="https://sleipnir.shop/css/owl.carousel.min.css">
    <link rel="stylesheet" href="https://sleipnir.shop/css/owl.theme.default.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">