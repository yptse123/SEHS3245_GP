1. Place SEHS3245_GP folder into C:\xampp\htdocs

2. Update sqls, first run 1_sehs3245_101_group_2_sleipnir.sql and then 2_count_sub_sp.sql

3. browser run: http://localhost/SEHS3245_GP/

-------------------------------------------------------------------

index.php = introduction page
mazda.php = product 1
mclaren.php = product 2
lamborghini.php  = product 3
cart.php = shopping cart page
success.php = thank you page

------

include = include files

------

bootstrap 3
https://getbootstrap.com/docs/3.4/getting-started/

jquery 1.12.4

------
** We use google cloud platform Lamp stack instance to host our website. With domain https://sleipnir.shop/, which also include ssl cert. And our github repo: https://github.com/yptse123/SEHS3245_GP **